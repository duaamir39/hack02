import { initializeApp } from "https://www.gstatic.com/firebasejs/10.3.1/firebase-app.js";

const firebaseConfig = {
  apiKey: "AIzaSyDombXu2AiS8IBgeLalXqEK2_ZYir4rnDI",
  authDomain: "attendance-app-6a5d9.firebaseapp.com",
  projectId: "attendance-app-6a5d9",
  storageBucket: "attendance-app-6a5d9.appspot.com",
  messagingSenderId: "549767724143",
  appId: "1:549767724143:web:4a6f2bcafed045a71ea19a"
};


const app = initializeApp(firebaseConfig);
